package team12.intouch.entities;

import android.content.Context;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.content.Context;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.util.Log;

public class GPSAPI implements GPS{
	private double lat;
	private double lng;
	
	public void createGPS(Context context) {
		LocationManager lm=(LocationManager)context.getSystemService(Context.LOCATION_SERVICE);
		boolean enabled = lm
		  .isProviderEnabled(LocationManager.GPS_PROVIDER);

		// check if enabled and if not send user to the GSP settings
		// Better solution would be to display a dialog and suggesting to 
		// go to the settings
		if (!enabled) {
			Log.e("GPS","NOT ENABLE");
		} 

		Criteria c=new Criteria(); 
		//if we pass false than
		//it will check first satellite location than Internet and than Sim Network
		
		
		String provider=lm.getBestProvider(c, false);
		Location l=lm.getLastKnownLocation(provider);
		
		if(l!=null)
		{
			lng=l.getLongitude();
			lat=l.getLatitude();
		}
		else
		{
			Log.e("GPS","DEAD");
			lng=-1;
			lat=-1;
		}
	}
	
	public double getLatitude() {
		return lat;
	}
	
	public double getLongitude() {
		return lng;
	}

	
}
